<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>pernikahan megah</title>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans|Roboto" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.materialdesignicons.com/2.1.19/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/datepicker.css">
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background: #fff;
            margin-top:6%;
        }
        .card-columns {
            column-count: 2;
        }
        .card {
            border-radius: 0;
            border: 0;
        }
        .card .card-img-top {
            border-radius: 0;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light fixed-top bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><img src="images/logo/MOMMYAMBOL.png" alt=""></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
                aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">RUMAH <span class="sr-only">(saat ini)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="pricing.php">HARGA</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="real-weddings.php">INSPIRASI</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="gallery.php">GALERI</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php">HUBUNGI KAMI</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about.php">TENTANG KAMI</a>
                </li>
            </ul>
            <div class="form-inline mr-2">
                <a class="mr-2" href="submit">
                    <i class="mdi mdi-star-outline" id="review" aria-hidden="true"></i> menulis </a>
                <a class="btn btn-sm my-2 my-sm-0" data-toggle="modal" data-target="#loginModal">
                    Login
                </a>
                <a class="btn btn-sm my-2 my-sm-0 mr-2 loginbtn" href="sign_up.php">Join</a>
            </div>
        </div>
    </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-lg-12 border-bottom mb-4">
            <h4 class="h2 text-center mb-0">pernikahan prolida klasik<br><b>Megan & Loukas</b></h4>
            <p class="text-muted text-center mt-2">FEBRUARY 18 &bigodot;
                PONTE VEDRA BEACH, FLORIDA</p>
        </div>
        <div class="col-lg-8">
            <div class="card-columns">
                <div class="card">
                    <img class="card-img-top" style="border-radius: 0" src="images/wedding/400x400_1517899737711-tpc-sawgrass-1.jpg" alt="Card image cap">
                </div>
                <div class="card">
                    <img class="card-img-top" style="border-radius: 0" src="images/wedding/400x400_1517899737847-classic-florida-clubhouse-wedding.jpg" alt="Card image cap">
                </div>
                <div class="card">
                    <img class="card-img-top" style="border-radius: 0" src="images/wedding/400x400_1517899745077-tpc-sawgrass-2.jpg" alt="Card image cap">
                </div>
                <div class="card">
                    <img class="card-img-top" style="border-radius: 0" src="images/wedding/400x400_1517899751541-tpc-sawgrass-3.jpg" alt="Card image cap">
                </div>
                <div class="card">
                    <img class="card-img-top" style="border-radius: 0" src="images/wedding/400x400_1517899758000-tpc-sawgrass-4.jpg" alt="Card image cap">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899764506-tpc-sawgrass-5.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899771149-tpc-sawgrass-6.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899791955-tpc-sawgrass-9.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899797972-tpc-sawgrass-10.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899824701-tpc-sawgrass-11.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899824712-tpc-sawgrass-12.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899831834-tpc-sawgrass-13.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/wedding/400x400_1517899838618-tpc-sawgrass-14.jpg" alt="Card image">
                </div>
                <div class="card">
                    <img class="card-img" style="border-radius: 0" src="images/real-weddings/post12/220x220_SQ_1511906215469-star-hill-ranch-2.jpg" alt="Card image">
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <h5>tentang galeri ini:</h5>
            <p class="font-weight-bold mb-0 mt-0">Mega & lokasi </p>
            <p class="mb-0">February 18</p>
            <p>Ponte Vedra Beach, Florida</p>

            <h5>Vendor:</h5>
            <p>menikah di TPC Sawgrass di Pantai Ponte Vedra, Florida pada 18 Februari.</p>
            <p>tempat: TPC Sawgrass</p>
            <p>Perencana: Acara Tanpa Penutup</p>
            <p>Gaun Pengantin: Pengantin yang Memikat</p>
            <p>Sepatu Pengantin: Jimmy Choo</p>
            <p>Gaun Pengiring Pengantin: Pengantin Lulu</p>
            <p>Pakaian Pengantin Pria: Tom James</p>
            <p>Pakaian Pengiring Pria: Vera Wang</p>
            <p>Penata Rambut: STUDIO BRIDE Riasan & Rambut</p>
            <p>Penata Rias: STUDIO BRIDE Rias & Rambut</p>
            <p>Undangan: Boneka Kertas</p>
            <p>Petugas: Pastor Michael Houle</p>
            <p>Desain Bunga: Toko Bunga Mawar Sharon Eropa</p>
            <p>Hiburan Resepsi: Suara Rahmat</p>
            <p>Katering: TPC Sawgrass</p>
            <p>Pembuat Roti: Kue Klasik</p>
            <p>Videografi: Film CollabCreation</p>
            <p>Transportasi: Layanan Limusin Golden Hinde</p>
        </div>


    </div>
</div>
<!-- MODAL LOGIN SECTION-->
<div class="modal fade" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="loginModal"><img src="images/logo/MOMMYAMBOL.png" alt=""></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="register.php" method="post">
                    <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Email:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputEmail" name="email"
                                   placeholder="Enter email">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword" class="col-sm-2 col-form-label">sandi:</label>
                        <div class="col-sm-10">
                            <input type="password" class="form-control" id="inputPassword" placeholder="Enter password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="login" class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-10">
                            <button type="button" class="btn btn-primary mr-2 custom-btn" style="font-size: 14px;">
                                gabung
                            </button>
                            <a href="" style="color: #22adb5;">lupa kata sandi Anda?</a>
                            <br/>
                            <div class="mt-2">Belum menjadi anggota?<a href="" style="color: #22adb5;">bergabung sekarang</a></div
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/jquery-3.2.1.slim.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>